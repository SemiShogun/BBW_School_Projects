package ch.bbw.jl.goodbyemoon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoodbyeMoonApplicationTests {

	@Test
	void contextLoads() {
	}

}
