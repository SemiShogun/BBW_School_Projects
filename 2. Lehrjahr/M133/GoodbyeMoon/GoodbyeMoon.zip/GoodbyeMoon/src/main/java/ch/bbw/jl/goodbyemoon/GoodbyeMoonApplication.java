package ch.bbw.jl.goodbyemoon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoodbyeMoonApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoodbyeMoonApplication.class, args);
	}

}
